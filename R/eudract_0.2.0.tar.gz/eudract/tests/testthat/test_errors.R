# Test when the varnames are missing some

# Test when there are extra superfluous variables

