library(testthat)
library(eudract)

test_check("eudract")

