This directory contains a fully worked example using SAS.

The master code file is "safety_summary.sas" which is commented to explain to some degree.

The raw data is in 'raw_safety.csv', and the remaining files needed to be able to use on your data are:

* soc_code.sas7bdat
* sas_xml_renaming.xslt
* simpleToEudraCT.xslt

You will then need to edit the code on lines 3-22.
