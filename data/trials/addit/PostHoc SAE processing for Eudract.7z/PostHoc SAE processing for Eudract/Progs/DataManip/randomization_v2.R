####################################################################################################
#Study: AdDIT
#
#Purpose: Preliminary final report
#
#Author: Sarah Dawson
#
#Creation date: 7th June 2016
#
#Last modified date: 7th June 2016
#
#Last modified by: Sarah Dawson
#
#Modification history: 7th June 2016 - copied randomization v2.R across from preliminary final analysis folder to final analysis folder. 
#
#Software: RStudio Version 0.98.945
#
#Input files: 
#
#Input programs: 
#
#Input libraries: 
#
#R Lines to be modified when unblinded: 
#               
####################################################################################################

# hardcoding needed due to data entry error
randomization=subset(randomization, id!=83)

#hardcoding needed to remove a patient randomised twice
randomization=subset(randomization, id!=305)

#Make all barcodes upper case
#randomization$barcode <- as.factor(toupper(randomization$barcode))
randomization$barcode <- toupper(as.character(randomization$barcode))

#hardcoding as the first 11 patients didn't get 
#a barcode.
#edits=data.frame(
#RandomNo=c(
#10360,
#10342,
#10341,
#10345,
#10303,
#10301,
#10259,
#10255,
#10253,
#10256,
#10254),
#Barcode=c(
#"20143023P",
#"20153509M",
#"20153549F",
#"20153591B",
#"20164191Y",
#"20164197E",
#"30108052S",
#"30108140P",
#"30108211R",
#"30108223E",
#"30108272H"),
#stringsAsFactors = FALSE
#)

#Remove erroneous entries
#randomization <- randomization[which(randomization$error==0),]

#index=match(edits$RandomNo, randomization$code)
#randomization$barcode=as.character(randomization$barcode)
#randomization[index,"barcode"]=edits$Barcode
levels(randomization$age)=c("> 13", "10 - 13")
randomization$age=factor(randomization$age, levels=c( "10 - 13","> 13"), ordered=T)
randomization$logAcr=factor(randomization$logAcr,
                            levels=c("1.2-1.7","> 1.7"),
                            ordered=T
)
levels(randomization$duration)=c("< 5", "5-10")
levels(randomization$cholesterol)=c("< 4.46", ">= 4.46")
randomization$hba1c=factor(randomization$hba1c, levels=c("< 7.5","7.5-8.5","> 8.5"), ordered=T)


#unblind=read.csv(paste(PATH, "/Data/Old data/unblind.csv",sep=""))
randomization=merge(randomization, unblind, by="code")
randomization$statin=factor(
  sub(".*/", "", randomization$treatment,perl=T),
  levels=c("Placebo","Statin"), ordered=T)

randomization$ACEI=factor(
  sub("/.*", "", randomization$treatment,perl=T),
  levels=c("Placebo","ACEI"), ordered=T)

date=randomization$dateRandom
randomization$dateRx=as.POSIXct(as.character(date), format="%d/%m/%Y %H:%M")
randomization$dateBirth=as.POSIXct(as.character(randomization$dateBirth), format="%d/%m/%Y")
randomization$dateRandom=as.POSIXct(as.character(randomization$dateRandom), format="%d/%m/%Y")