groupheader=function(meta, header, cols){

# This adds rows appropriately to a Meta file for subsequently processing
# by the 'output' function to added headings across rows
# the input is:
#
# meta- an existing meta data set
# headers- a character vector of headings to apply across multiple columns
# cols- a list the same length as headers, each element giving the number of
# the columns to span across
#
## Note the headers and cols arguments must be given in increasing order.
## To use nested you can repeatedly use this function. But the column numbers are 
## increased each time (so a the meta data reads as if a new column is inserted
## before each group that is spanned.  
## example 
## meta=groupheader(meta, c("span 1 & 2","span 3 &4"), list(1:2, 3:4))
## meta=groupheader(meta, c("nested across 1 -4"), list( 1:6))



n=max(meta$colnumber)
m=length(header)

colnumber=unlist(lapply(cols,min))-0.5
parent=colnumber+0.5+0:(m-1)

varnames=rep("",m)
parentcol=rep(NA,m)
headings=header
justification=rep("c",m)
width=rep("",m)
vnum=rep(NA,m)
newrows=cbind(varnames,colnumber,parentcol, headings, justification, width,vnum)
if( dim(meta)[2]==6){
meta=cbind(meta,vnum=meta$colnumber)
}

meta=rbind(meta, newrows)
meta$parentcol=ifelse(is.na(meta$parentcol),NA,as.numeric(meta$parentcol)+1)
for( i in 1:length(cols) ){
temp=meta[meta$colnumber %in% cols[[i]],"parentcol"]
meta[meta$colnumber %in% cols[[i]],"parentcol"]=ifelse(is.na(temp),parent[i],temp)
}
index=order(meta$colnumber)
meta=meta[index,]
meta$colnumber=1:(n+m)
meta
}