
prettyP=function(x){
prettyNum(x, digits=3,nsmall=2,width=5)
}
