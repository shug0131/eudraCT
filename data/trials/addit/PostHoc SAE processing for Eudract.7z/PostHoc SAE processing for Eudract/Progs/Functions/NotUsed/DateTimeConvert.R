DateTimeConvert=function(date,time){
date=as.character(date)
time=as.character(time)
dt=paste(date,time)
dt=ifelse(dt=="NA NA", NA, dt)
as.POSIXct(dt,tz="GMT")
}