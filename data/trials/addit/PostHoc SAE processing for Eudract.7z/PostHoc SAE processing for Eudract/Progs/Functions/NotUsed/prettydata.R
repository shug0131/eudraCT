prettydata=function(data, digits=3){
apply(data,2,format, digits=digits, width=digits+2)
}
