convertlookup=function(data,look=lookups,name=deparse(substitute(data))){

vars=subset(look, sourcetable==name)
for( var in vars$sourcetablevar){
table=subset(vars, sourcetablevar==var)

code=read.csv(file=paste(DATA, table$lookuptable,"exportver",VER,".csv",sep=""))

data[,var]=factor( as.character(data[,var]),
	levels=code[,1],
	labels=code[,2]
)
}
data
}

 