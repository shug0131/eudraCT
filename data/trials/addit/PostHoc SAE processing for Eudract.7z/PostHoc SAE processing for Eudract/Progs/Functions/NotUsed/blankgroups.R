
blankgroups=function(x){
n=length(x)
x=as.character(x)
y=c(FALSE, x[-n])
blank= (y==x)
ifelse(blank," ",x)
}

