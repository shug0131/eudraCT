
elders=function(x,node ,parent){
  x=parent[match(x,node)]
  x=x[!is.na(x)]
  unique(x)
  }

exclude=function(x,y){
  x[!(x%in%y)]
}
  

tree=function(node,parent){
  L=list(node)
  if( all(is.na(parent))){return(L)}
  else{
    i=1
    while( length(elders(L[[i]],node,parent))>0){
      L=c(L,list(elders(L[[i]],node,parent)))
      for(j in 1:i){
	L[[j]]=exclude(L[[j]],L[[i+1]])
      }
      i=i+1
    }
    L
  }
}

  
level=function(node, L){
  M=length(L)
  level=rep(1,length(node))
  for( i in 1:length(node)){
    for(j in 1:M){
      if( node[i] %in% L[[j]]){level[i]=j} 
    }
  }
  level
}


lohi=function(node,parent,L){
  lo=node
  hi=node
  M=length(L)
  if(M>1){
    for( i in 2:M){
      for( j in L[[i]]){
        ind=match(j,node)
	lo[ind]=min(lo[parent==j&!is.na(parent)])
	hi[ind]=max(hi[parent==j&!is.na(parent)])
	
      }
      
    }
  }
  cbind(lo=lo, hi=hi)
}




children=function(node, parent){
child=NULL
for( nod in node){
 child=c(child, list(c(node[parent==nod & !is.na(parent)])))
}
child
}



process=function(nodenow,node, kid, levs,title,vnum){
	temp=1:length(nodenow)
	for( i in 1:length(nodenow)){
		if( levs[nodenow[i]]==1){temp[i]=paste("var",vnum[nodenow[i]],sep="")}
		else{ head=paste('"',title[nodenow[i]],'"',sep="")
		temp[i]=paste("(", head ,Recall(kid[[nodenow[i]]],node,kid, levs,title,vnum),")", collapse=" ") }
	}
	paste(temp, collapse=" ")
}


colstatement=function(meta){
if( dim(meta)[2]==6){vnum=meta$colnumber}
else{vnum=as.numeric(meta$vnum)}
node=as.numeric(meta$colnumber)
parent=as.numeric(meta$parentcol)
title=meta$heading
index=order(node)
node=node[index]
parent=parent[index]
title=title[index]
vnum=vnum[index]

L=tree(node,parent)
levels=level(node,L)
kids=children(node,parent)

if(max(levels)==1){ paste(paste("var",vnum,sep=""),collapse=" ")}
else{
start=node[is.na(parent)]
process(start,node,kids,levels,title,vnum)
}

}

