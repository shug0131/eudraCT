import=function(name){


x=read.csv(
file=paste(DATA,name,"exportver",VER,".csv",sep=""),
header=T,
na.string="NULL")
x=convertlookup(x,name=name)
x$trialid=as.character(x$trialid)
assign(name,x,envir=.GlobalEnv)
rm(x)
}