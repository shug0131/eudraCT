lookup=function(data, variable,code){
code=read.csv(file=code)
data$variable=factor( as.character(data$variable),
	levels=code$code,
	labels=code$desc
)
}

