add.tabotab=function(data, item, value){
  if(!all(names(data)==c("name","item","value"))){stop("Not a valid tabotab dataset")}
  if( length(unique(data$name))>1){stop("there is more than one table refered to here")}
  if( any( data$item %in% item)){stop("you are adding items that already exist")}
  name=unique(data$name)
  n=length(item)
  rbind( data, data.frame(name=rep(name,n), item=item, value=value))
      }
