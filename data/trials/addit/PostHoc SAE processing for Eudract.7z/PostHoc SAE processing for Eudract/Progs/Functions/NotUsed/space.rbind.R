
space.rbind=function(...){
ll=list(...)
col=dim(ll[[1]])[2]
ll=lapply(ll, function(x){ apply(as.data.frame(x),2,as.character)})
ll=lapply(ll,function(x){rbind(x,rep(" ",col))})
ans=NULL
for( i in 1:length(ll)){
	ans=rbind(ans, ll[[i]])
}
as.data.frame(ans)
}
