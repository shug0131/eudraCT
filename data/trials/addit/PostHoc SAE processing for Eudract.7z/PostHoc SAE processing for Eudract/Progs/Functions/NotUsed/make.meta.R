make.meta=function(data,
       varnames=names(data),
       colnumber=1:(dim(data)[2]),
       parentcol=rep(NA,dim(data)[2]),headings=names(data),
       justification=rep("r",dim(data)[2]),
       width=rep("", dim(data)[2])){

data.frame(varnames, colnumber, parentcol,headings, justification, width)
}  
