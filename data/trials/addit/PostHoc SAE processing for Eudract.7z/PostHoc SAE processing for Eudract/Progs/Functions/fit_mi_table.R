#### Function to output the results from multiple imputation to XML format


fit_mi_table <- function(fit, var_names, number){
  tab<- as.data.frame(round(summary(fit)[,-5],4))
  tab$ci <- paste(tab[,3], tab[,4], sep=", ")
  tab$p_value <- 2*(1- pnorm(abs(tab[,1]/tab[,2])))
  tab$p_value <- ifelse(tab$p_value < 0.0001, "<0.0001", round(tab$p_value,4))
  tab <- tab[,c("results","ci","se","p_value")]
  tab <- data.frame(var_names, tab)
  colnames(tab) <- c("Variable", "Estimate", "95% confidence interval", "Standard error", "P-value")
  WriteTable(tab, number) 
}