######
###  Extract the details of a fitted model inlcuding all variance covariance
####
## input: a lm object, a reference number, PATH, PROGNAME (both defined in the calling environment)
## output: a csv file , and an edit to the table of tables to give the PROGNAME
###################

export.lm <- function(fit, number){
  if( class(fit)!="lm"){warning ("only designed for lm objects")}
  
  
  fit_summary <- summary(fit)
  vcv <- vcov(fit_summary)
  coef <- coefficients(fit)
  
  output_string <- NULL
  paste_plus <- function(..., initial=output_string){
    arg_name <- deparse(substitute(initial))
    initial <- paste(initial, ...)
    assign(arg_name, initial, envir = parent.frame())
  }
  col <- max(length(coef),2)
  
  varnames <- names(coef)

  #EXCEL doesn't like spaces between the seperating commas !!!
  
  paste_plus("Coefficients", paste(rep(",", col-1), collapse=""),"\n")
  paste_plus(paste0( paste0("\"",varnames,"\""), collapse = ","),"\n") 
  paste_plus(paste(coef, collapse = ","),"\n")  
  paste_plus( "Residual SE, DF", paste(rep(",",col-2), collapse=""),"\n") 
  paste_plus(fit_summary$sigma,", ", fit_summary$df[2], paste(rep(",",col-2), collapse=""),"\n" ) 
  paste_plus("\nCovariance of coefficients", paste(rep(",", col-1), collapse=""), "\n")
  paste_plus(paste0( paste0("\"",varnames,"\""), collapse = ","),"\n") 
  for( row in 1:col){
    paste_plus( paste(vcv[row,],collapse = ","),"\n")
  }
  
  cat(output_string, file = paste0(PATH,"/Output/core/table_",number,".csv"))
   
  CallingProg=paste(getwd(), PROGNAME,sep="/")
  TableofTables[!is.na(TableofTables$Number) & as.character(TableofTables$Number)==number,"Program"] <- CallingProg
  assign("TableofTables", TableofTables, envir= .GlobalEnv)
  
  df <- data.frame(paste0("See file table_",number,".csv in the appendix"))
  names(df) <- ""
  WriteTable(df, number=number)
  
  
} 


