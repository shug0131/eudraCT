####################################################################################################
#Study: N/A
#
#Purpose: to re-name the variables between different Macro data downloads where inconsistent 
#character lengths have been used for the variable names between different downloads.
#
#Author: Sarah Dawson
#
#Creation date: 23rd September 2016
#
#Last modified date: 5th October 2016
#
#Last modified by: Sarah Dawson
#
#Modification history: 23rd September 2016 - R file created.  
#                      5th October - Added in the header section. Improving the code and turning it into a function.
#
#Software: RStudio Version 0.98.945
#
#Input files: 
#
#Input programs:
#
#Input libraries: 
#
#R Lines to be modified when unblinded: N/A
#               
####################################################################################################

#Clear objects
#rm(list=ls())

#Set working directory
#PATH1="V:/DOWNLOADS/Addit"

#Read in Macro datasets and associated DLU files

#Download 1 - the first data set with the variable names you wish to use
#addit_unsch_old <- read.csv(file=paste(PATH1, "/AdDIT_export_20160314/AdditExport20160314 MACRO/AdditExport20160314/ADDIT20160314_2.csv", sep=""), header=T) 
#DLU2_old <- read.csv(file=paste(PATH1, "/AdDIT_export_20160314/AdditExport20160314 MACRO/AdditExport20160314/ADDIT20160314_2_DLU.csv", sep=""), stringsAsFactors = FALSE,header=T)

#Download 2 - the second data set with the variable names you wish the change to match download 1
#addit_unsch_new <- read.csv(file=paste(PATH1, "/AdditExport20160907 MACRO/ADDIT20160907_2.csv", sep=""), header=T) 
#DLU2_new <- read.csv(file=paste(PATH1, "/AdditExport20160907 MACRO/ADDIT20160907_2_DLU.csv", sep=""), stringsAsFactors = FALSE,header=T)

#Try to put this into a function or loop

DLU_ShortCode_Rename <- function(old_data_DLU, new_data_DLU, new_data) {
  
  #Pick out DLU file column headings
  DLU.names <- colnames(old_data_DLU) 
  
  #Specify ordering
  new_data_DLU$Order <- 1:nrow(new_data_DLU)
 
  #Compare the list of variables to make sure there are no new ones and that none have been dropped
  table(new_data_DLU$Visit.Form.Question %in% old_data_DLU$Visit.Form.Question) 
  table(old_data_DLU$Visit.Form.Question %in% new_data_DLU$Visit.Form.Question)

  #Merge on Visit Form Question which is consistent from one download to the next regardless of settings
  merge2 <- merge(new_data_DLU, old_data_DLU, by=c("Visit.Form.Question", "Description", "Type"), all=T)
  
  #Reorder the merged data so that the order matches that of the original DLU files
  merge2 <- merge2[order(merge2$Order),] 
  
  #Rename the variables in the dataset to match the updated names in the corresponding DLU file
  colnames(new_data) <- c(colnames(new_data[1:7]), ifelse(colnames(new_data[8:length(colnames(new_data))]) %in% merge2$ShortCode.x, merge2$ShortCode.y, NA))
    
  #Replace shortcodes in DLU_new with those from DLU_old and re-set column headings in the DLU file
  new_data_DLU <- merge2[,c("ShortCode.y", "Visit.Form.Question", "Description", "Type")]
  colnames(new_data_DLU) <- DLU.names
  return(list(new_data_DLU, new_data))
  
}

#results <- DLU_ShortCode_Rename(DLU2_old, DLU2_new, addit_unsch_new)

#DLU2_new <- data.frame(results[1])
#addit_unsch_new <- data.frame(results[2])

#head(DLU2_old)
#head(DLU2_new)