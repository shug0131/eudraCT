#This function takes a character string and outputs it converts to Proper Case.

propercase=function(x){
gsub("(\\w)(\\w*)", "\\U\\1\\L\\2",x, perl=TRUE)
}
