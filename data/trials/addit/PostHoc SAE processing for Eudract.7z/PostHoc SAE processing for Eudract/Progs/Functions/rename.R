rename=function(data,old,new){
  which=match(old,names(data))
  if(any(is.na(which))){stop("incorrect old variable names")}
  else{names(data)[which]<-new}
  data
}