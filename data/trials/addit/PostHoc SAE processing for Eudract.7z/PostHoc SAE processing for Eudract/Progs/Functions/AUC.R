#### Functions to calculate AUC values
#### used by ACR.R, secondary_analysise.R, Blood_pressure.R, BP_zscore.R
#### Created by Simon Bond
### 25 August 2016
############################

#Extract from SAP:AUC will be calculated from date of randomisation, which will include that part of the curve
#from randomisation to first follow-up, but exclude the part between screening and randomisation.
#This function does this.

removepreRand <- function(x,y){
  #x, are sorted in order
  #no missing values
  #find i,j st. x[i] <= 0 <= x[j]
  n <- length(x)
  i <- sum(x<=0)
  j <- n-sum(0<=x)+1
  
  #all prior to 0
  if(i==n){x <- y <-numeric(0)}
  #all after 0, extrapolate back to zero
  if(i==0){ 
    y0 <- y[1]-x[1]*(y[2]-y[1])/(x[2]-x[1])
    y <- c(y0,y)
    x <- c(0,x)
    
  }
  
  if(0<i & 0<j & j<=n){
    #when we  have an exact x=0
    if( i==j){
      y <- c(y[j:n])
      x <- c(x[j:n])
    }else{
      #interpolate the y value
      omega_i <- x[j]/(x[j]-x[i])
      omega_j <- -x[i]/(x[j]-x[i])
      y0 <- y[i]*omega_i+y[j]*omega_j
      y <- c(y0, y[j:n])
      x <- c(0, x[j:n])
    }
  }
  list(x=x, y=y)
}

#x <- (-10):(-5)
#y <- rnorm(length(x))
#plot(x,y, type="l", xlim=c( min(0,min(x)),max(0,max(x)))) 
#lines(removepreRand(x,y), col="red")

AUC=function(index,data){
  #implements the trapezium rule on a subset of the data
  x=data[index,2]
  y=data[index,1]
  #deal with missing values
  keep <- !is.na(x)&!is.na(y)
  x <- x[keep]
  y <- y[keep]
  n <- sum(keep)
  if(n==1 && x>=0 ){return(y)}
  if(n==0){return(NA)}
  #implicit ELSE logic
  reorder=order(x)
  x=x[reorder]
  y=y[reorder]
  obj <- removepreRand(x,y)
  x <- obj$x
  y <- obj$y
  #might have added a point at the origin, might not though!
  n <- length(x)
  if(n>1){
    dx=diff(x)
    ybar=(y[1:(n-1)]+y[2:n])/2
    return(sum(dx*ybar)/sum(dx))
  }
  #need to check again incase removepreRand() only gives back 1 point
  if(n==1 && x>=0 ){return(y)}
  if(n==0){return(NA)}
}
#auc=tapply(1:dim(urine2)[1], data=urine2[,c("stdLogACR","Time")], 
#           INDEX=list(urine2$patId),
#           FUN=AUC)