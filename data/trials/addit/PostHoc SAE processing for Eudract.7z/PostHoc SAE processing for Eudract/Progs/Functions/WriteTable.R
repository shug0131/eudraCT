
################################################
## Study: Library Function
## Program name: WriteTable.R
## Purpose: Takes a data frame and writes it in xml format to the output directory with the desired file name
## Creation Date: 11/11/2014
## Author: Simon Bond
## R Version: 3.1.0 (2014-04-10) -- "Spring Dance"
## Input: A table, an index number, optionally heading text. NEEDS PATH to set the root directory 
## and PROGNAME to set the name of file (not it's path though)
## Calling Program: functions.R
## output: an xml file in the Output\Core folder
###############################################
## Modification History
## Date       Initials        Description
###############################################



WriteTable=function(X,number,
                    #file=paste(PATH,"\\Output\\Core\\table_",number,".xml",sep=""),
                    file=paste(PATH,"/Output/Core/table_",number,".xml",sep="") #,
                    ,
                    heading=colnames(X)
                    ){
  
  require(XML)  
  
  # PATH and PROGNAME  need to be defined in the evironment that calls this function
  if( is.null(PATH)){PATH=getwd()}
  if( is.null(PROGNAME)){PROGNAME="Program missing"}
  
  output_string <- NULL
  paste_plus <- function(..., initial=output_string){
    arg_name <- deparse(substitute(initial))
    initial <- paste(initial, ...)
    assign(arg_name, initial, envir = parent.frame())
  }
  
  
  paste_plus("<table>\n<tr>")
  for( col in 1:dim(X)[2]){
    paste_plus("<td>",heading[col],"</td>")
  }
  paste_plus("</tr>\n")
  for(row in 1:dim(X)[1]){
    paste_plus("<tr>")
    for(col in 1:dim(X)[2]){
      text=as.character(X[row,col])
      text=gsub("&","&amp;", text)
      text=gsub("<","&lt;", text)
      text=gsub(">", "&gt;",text)
      paste_plus("<td>", text,"</td>")
      
    }
    paste_plus("</tr>\n")
  }
  paste_plus("</table>\n")
  
  cat(output_string, file=file, append=FALSE)
########  
#   #This automatically writes the programe that calls this function  
#   
#   
#! Could not get this to work inside the function. Running outside WriteTable instead.
CallingProg=paste(getwd(), PROGNAME,sep="/")
TableofTables[!is.na(TableofTables$Number) & as.character(TableofTables$Number)==number,"Program"] <- CallingProg
assign("TableofTables", TableofTables, envir= .GlobalEnv)


}