barcode_to_uppercase <- function(data_name, replace = TRUE){
  data <- get(data_name, envir= parent.frame())
  varnames <- names(data)
  varnames <- tolower(varnames)
  index <- grep("barcode",varnames)
  if(any(index)){
    data[,index] <- toupper(data[,index])
    #naughty inteference with calling environment
    if(replace){
      assign(data_name, data, envir= parent.frame())
    }
  }
  if(!replace){
    data
  }
}

