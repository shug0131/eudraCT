##wrapper function to save typing, avoid errors
## We have to apply the chdir=TRUE argument to record the correct file path with printing the 
## code file in the footnote of the output 
srce <- function(file, backup = FALSE){
  #to allow you to rewind an re-run code
  if(backup){ save.image(file=paste0(PATH,"/Output/R_images/backup.Rdata"))}
  #use load( file=paste0(PATH,"/Output/R_images/backup.Rdata"))
  #before re-runing if needed.
  source(paste0("Progs/Analysis/",file), chdir = TRUE)
}