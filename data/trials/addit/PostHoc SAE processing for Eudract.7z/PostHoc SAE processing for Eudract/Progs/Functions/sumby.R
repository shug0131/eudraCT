sumby=function(var, arm, label=NULL){
var.class=class(var)
if(inherits(var,"numeric")|| inherits(var,"integer")){
	mu=format(tapply(var,arm,mean, na.rm=T), digits=3, width=2)
	sd=format(tapply(var,arm,sd, na.rm=T), digits=3, width=2)
	n=tapply(var,arm, function(x){sum(!is.na(x))})
	meds=tapply(var, arm, median, na.rm=T)
	mins=tapply(var,arm, min, na.rm=T)
	maxs=tapply(var,arm, max, na.rm=T)
	if(is.null(label)){variable=c(propercase(deparse(substitute(var))),"","","")}
	else{ variable=c(label,"","","")}
	stats=c("n","Mean (SD)","Median","Min, Max")
	value=rbind(n,paste(mu," (",sd,")",sep=""),meds, paste(mins,", ", maxs,sep=""))
	ans=data.frame(cbind(variable, stats, value),row.names=1:4)
}	
if( inherits(var,"factor")){
tab=table(var, arm)
dims=dim(tab)
nams=dimnames(tab)
tab=as.data.frame(tab)
total=matrix(rep(with(tab,tapply(Freq,arm,sum)),dims[1]), nrow=dims[1],byrow=T)

tab=reshape(tab, direction="wide", v.names="Freq", timevar="arm", idvar="var")
if(is.null(label)){variable=c(propercase(deparse(substitute(var))),rep("",dims[1]-1))}
	else{ variable=c(label,rep("",dims[1]-1))}

stats=propercase(tab[,1])
tab=tab[,-1]
perc=round(100*tab/total,1)

X=array(0,dim=c(dim(perc),3))
X[,,1]=as.matrix(perc)
X[,,2]=as.matrix(tab)
X[,,3]=as.matrix(total)

perpast=function(x){
paste(x[1],"% (",x[2],"/",x[3],")",sep="")
}
value=apply(X,c(1,2),perpast)
colnames(value)=nams[[2]]

ans=data.frame(cbind(variable, stats, value),row.names=1:dims[1])


}

apply(ans,2,as.character)
}
