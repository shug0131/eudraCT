################################################
## Study:Library Function
## Program name: orderDewey.R
## Purpose: Orders a set of character vectors by Dewey Decimal system
## Creation Date: 21/1/2015
## Author: Simon Bond
## R Version: 3.1.0 (2014-04-10) -- "Spring Dance"
## Input: a characeter vector  of "numbers" 
## Calling Program: NA library function
## output: a permutation vector
###############################################
## Modification History
## Date       Initials        Description
## 27/5/15    SJB             dealing with x being just a list of numbers
###############################################





orderDewey=function(x){
  #sorts numbers of the form 10.1.23, with arbitrary numbers of decimal points
  #and makes sure that 10.2< 10.10
  if( class(x)!="character"){stop("Must input a character vector")}
#split up the string into a list of vectors broken by decimals
  X=strsplit(x,"\\.")
# FInd out the longest length
  nrow=max(sapply(X,length))
#Pad the empty elements out and return a matrix
  X=sapply(X, function(x){c(as.integer(x), rep(NA,nrow-length(x)))  })
  if( class(X)=="integer"){ 
    # when x is just a list of numbers
    X= as.data.frame(X)
  } else if ( class(X)=="matrix"){ 
    #otherwise it is a matrix that needs to be transposed
    X=as.data.frame(t(X))
  } else {
    stop("The input must be a 1 dimensional character vector")
  } 
# a trick to get X technically as a list of columns, and then allow
# order() over an arbitrary number of columns as arguments to break ties
  do.call(order,X)
}


