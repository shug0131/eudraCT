change_from_base <- function(mod, baseline_col, treat_col){
  # only adjust the main baseline_col, even if it is a piecewise function
    theta <- mod$coefficients
  theta[baseline_col] <- theta[baseline_col] - 1
  X <- model.matrix(mod)
  mod.sum <- summary(mod)
  Sigma <- mod.sum$cov.unscaled*mod.sum$sigma^2
  X_mean <- aggregate(X~X[,treat_col],FUN=mean,data=X)
  labels <- X_mean[,1]
    contr <- as.matrix(X_mean[,-1])
  mu <- as.vector(contr%*%theta)
  sigma <- contr%*%Sigma%*%t(contr)
  sigma<-sqrt(diag(sigma)) 
  names(mu) <- names(sigma) <- labels
  list("mu"=mu, "se"=sigma)
}

#mod11.01.pw
#diff(change_from_base(mod11.01.pw, 16,3 )$mu)
#sqrt(sum(change_from_base(mod11.01.pw, 16,2 )$se^2))
#summary(mod11.01.pw)

base_change_output <- function(label, mod, baseline_col, treat_col, 
                               file=paste0(PATH,"/Output/Reports/baselinechange.txt"), 
                               append=TRUE){
  obj <- change_from_base(mod, baseline_col, treat_col)
  cat("\n", label,"\nMean Change\n",obj[[1]],"\nS.E.\n", obj[[2]],"\n\n", 
      file=file, append=append)
  
}


