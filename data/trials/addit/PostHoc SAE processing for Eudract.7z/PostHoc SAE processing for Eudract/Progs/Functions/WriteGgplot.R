WriteGgplot=function(number, plot=last_plot(),  width=29.7*0.6,height=21*0.6,dpi=300,units="cm",...){
  require(ggplot2)  
  
  # TableofTables, PATH, and PROGNAME  need to be defined in the evironment that calls this function
  if( is.null(PATH)){PATH=getwd()}
  if( is.null(PROGNAME)){PROGNAME="Program missing"}
  CallingProg=paste(getwd(), PROGNAME,sep="/")
  TableofTables[!is.na(TableofTables$Number) & as.character(TableofTables$Number)==number,"Program"] <- CallingProg
  assign("TableofTables", TableofTables, envir= .GlobalEnv)
  
  #Deals with non-ggplot objects as well now
  grDevices::png(file=paste0(PATH, "//Output//Figures//fig_", number,".png"), 
            height=height, width=width, units=units, res=dpi, ...)
  on.exit(capture.output(dev.off()))
  plot(plot)
  invisible() 
}