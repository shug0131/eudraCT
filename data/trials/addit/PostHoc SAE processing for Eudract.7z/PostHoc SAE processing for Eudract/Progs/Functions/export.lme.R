######
###  Extract the details of a fitted model inlcuding all variance covariance
####
## input: a lme object, a reference number, PATH, PROGNAME (both defined in the calling environment)
## output: a csv file , and an edit to the table of tables to give the PROGNAME
###################

export.lme <- function(fit, number){
  if( class(fit)!="lme"){warning ("only designed for lme objects")}
  
  
  fit_summary <- summary(fit)
  vcv <- vcov(fit_summary)
  coef <- fixef(fit)
  covar <- VarCorr(fit)
  
  output_string <- NULL
  paste_plus <- function(..., initial=output_string){
    arg_name <- deparse(substitute(initial))
    initial <- paste(initial, ...)
    assign(arg_name, initial, envir = parent.frame())
  }
  col <- max(length(coef),4)
  
  varnames <- names(coef)

  #EXCEL doesn't like spaces between the seperating commas !!!
  
  paste_plus("Coefficients", paste(rep(",", col-1), collapse=""),"\n")
  paste_plus(paste0( paste0("\"",varnames,"\""), collapse = ","),"\n") 
  paste_plus(paste(coef, collapse = ","),"\n")  
  paste_plus("\nCovariance of coefficients", paste(rep(",", col-1), collapse=""), "\n")
  paste_plus(paste0( paste0("\"",varnames,"\""), collapse = ","),"\n") 
  for( row in 1:col){
    paste_plus( paste(vcv[row,],collapse = ","),"\n")
  }
  paste_plus("Covariance Parameter Estimates\n\n")
  paste_plus("Component,", paste0(dimnames(covar)[[2]], collapse = ","), "\n")
  for( row in 1:dim(covar)[1]){
    paste_plus( dimnames(covar)[[1]][row], "," , paste0(covar[row,], collapse=","), "\n")
  }
  
   
  cat(output_string, file = paste0(PATH,"/Output/core/table_",number,".csv"))
   
  CallingProg=paste(getwd(), PROGNAME,sep="/")
  TableofTables[!is.na(TableofTables$Number) & as.character(TableofTables$Number)==number,"Program"] <- CallingProg
  assign("TableofTables", TableofTables, envir= .GlobalEnv)
  
  df <- data.frame(paste0("See file table_",number,".csv in the appendix"))
  names(df) <- ""
  WriteTable(df, number=number)
  
} 


