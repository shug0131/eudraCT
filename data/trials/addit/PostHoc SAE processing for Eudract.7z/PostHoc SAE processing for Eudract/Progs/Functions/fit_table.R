##### FUnction to rproduce summary dataframe for a lm/lme model 
##inputs: a model, a set of variable names, a table number

fit_table <- function(fit, var_names, number){
  tab<- as.data.frame(round(summary(fit)$coefficients,4))
  tab$lowerci <- round(tab[1][[1]] - (1.96*tab[2][[1]]),2)
  tab$upperci <- round(tab[1][[1]] + (1.96*tab[2][[1]]),2)
  tab$ci <- paste(tab$lowerci, tab$upperci, sep=", ")
  tab <- tab[c(1,7,2,4)]
  tab[,4] <- ifelse(tab[,4]<0.0001, "<0.0001", tab[,4])
  tab <- data.frame(var_names, tab)
  colnames(tab) <- c("Variable", "Estimate", "95% confidence interval", "Standard error", "P-value")
  WriteTable(tab, number) 
}