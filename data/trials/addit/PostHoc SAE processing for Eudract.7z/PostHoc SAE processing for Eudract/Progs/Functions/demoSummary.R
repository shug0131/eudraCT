demoSummary=function( row, data){
  x=sumby(data[,vars[row,"varname"]],
          data[,"treatment"], 
          label=vars[row, "label"]  )
  y=sumby(data[,vars[row,"varname"]],
          data[,"statin"], 
          label=vars[row, "label"]  )
  z=sumby(data[,vars[row,"varname"]],
          data[,"ACEI"], 
          label=vars[row, "label"]  )
  cbind(x,y[,-c(1:2)],z[,-c(1:2)])
}
