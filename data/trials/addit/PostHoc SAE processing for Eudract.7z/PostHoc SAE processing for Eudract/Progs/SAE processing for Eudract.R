####################################################################################################
#Study: AdDIT
#
#Purpose: SAE processing for Eudract
#
#Author: Sarah Dawson
#
#Creation date: 6th March 2017
#
#Last modified date: 7th March 2017
#
#Last modified by: Sarah Dawson
#a
#Modification history: 
#6th March 2017 - R file created. Read in data. Started to process the data for the EudractSafetyXml R package.
#7th March 2017 - Added in treatment assignments.
#
#Software: RStudio Version 1.0.136
#
#Input files:
#V:/DOWNLOADS/Addit/AdditExport20161206 External/SAE Log07092016.csv
#
#Input programs: 
#
#
#Input libraries: 
#plyr
#xml2
#EudractSafetyXml
#
#R Lines to be modified when unblinded: n/a
#               
####################################################################################################

#Remove any background objects

rm(list=ls())

#Set working directory

PATH="V:/STATISTICS/Addit/Analysis/PostHoc SAE processing for Eudract" 
PATH1="V:/DOWNLOADS/Addit"
setwd(PATH)

#Set location for output

OUTPUTDATA=paste(PATH,"\\Progs\\Output",sep="" )

#Load data

safety <- read.csv(paste0(PATH,"/Data/SAE Log 07092016 ts.csv"), header=T, skip=1)
randomization <- read.csv(file=paste(PATH, "/Data/Randomisation 10April2014.csv",sep=""),header=T)
unblind <- read.csv(file=paste(PATH, "/Data/unblind.csv",sep=""), header=T)

#Load Simon's Eudract SAE reporting R package

#install.packages("xml2")
#install.packages("V:/STATISTICS/NON STUDY FOLDER/EudractAEs/EudractSafetyXml_0.1.0.zip", repos = NULL, type = "win.binary")

library(EudractSafetyXml)
#library(XML)
library(xml2)

#Remove blank rows, cols from safety data set

blank_row <- apply(safety,1, function(x){ all(is.na(x)|(x==""))})
blank_col <- apply(safety,2, function(x){ all(is.na(x)|(x==""))})
safety <- safety[!blank_row,!blank_col]
rm(blank_row, blank_col)

#Process the randomisation data

source(paste0(PATH,"/Progs/DataManip/randomization_v2.R"))

#Merge treatment assignments into safety dataset

safety$Barcode <- toupper(safety$Barcode)
randomization$barcode <- toupper(randomization$barcode)

safety <- merge(safety, 
                subset(randomization, select=c(barcode, treatment)),
                       by.x="Barcode", by.y="barcode",
                       all.x=TRUE)



#Inputs for EudractSafetyXml

#Groups are ordered as: c("ACE Inhibitor + Placebo", "ACE Inhibitor + Statin", 
#                         "Placebo + Placebo", "Placebo + Statin")

#####HARD CODING - NEED TO DO THIS PROGRAMATICALLY WHEN REST OF CODE IS WORKING#####

subjectsExposed <- c(111,111,109,112) #Number of subjects in each treatment arm (numbers TBC)

deathsExternal <- c(0,0,0,0) #Number of deaths in each treatment arm (numbers TBC)
## this has been confirmed

####END OF HARD CODING####

nonSeriousEventFrequencyThreshold <- 0 #to be used to filter out events that are rarer than this threshold (%)

safety$related <- ifelse(safety$Relationship.to.study.drugs=="possible" | 
                           safety$Relationship.to.study.drugs=="probable",  
                           TRUE, 
                           ifelse(safety$Relationship.to.study.drugs=="unlikely" |
                                    safety$Relationship.to.study.drugs=="unrelated" |
                                  safety$Relationship.to.study.drugs=="unrelated ", 
                                  FALSE, NA))
summary(safety$related)
#subset(safety, is.na(related))
#NEEDS TO BE QUERIED!!
safety$fatal <- FALSE
#Confirmed
safety$serious <- TRUE

#merge in with the MedDra data

medra_dictionary <- read.table("Data/pt.asc", sep="$", header=F, quote = "")[,c(1,2,4)]
colnames(medra_dictionary) <- c("pt_code", "pt_name", "soc_code")
safety <- merge(safety, medra_dictionary, by.x="MedDRA.Term.ID", by.y="pt_code", all.x=TRUE)

# Queries where teh PT code doesn't match anything in the dictionary.
# CHeck the latest version of the dictionary, and/or send queries

old_name <- c("SAE.Ref.","MedDRA.Term.ID","Barcode","related", "SOC.Code","fatal","serious","treatment", "pt_name")
new_name <- c("SAE.Ref","pt", "subjid", "related", "soc","fatal","serious","group","term")
names(safety)[match( old_name, names(safety))] <- new_name

safety <- safety[new_name]
rm(new_name, old_name)
safety <- merge(safety, soc_code, by.x = "soc", by.y = "meddra", all.x = TRUE)


# QUERY GENERATE HERE

missing <- apply(safety, 1, function(x){any(is.na(x))})
safety_queries <- safety[missing,]
write.csv(safety_queries, file="safety_queries.csv", row.names = FALSE)

safety <- safety[!missing,]


rm(missing)

#Prepare tables

# Group level statistics

# to make sure we have a fatality, or serious, or non-serious if it exists
# within each patient.


df_group <- aggregate(cbind(deathsResultingFromAdverseEvents = fatal, subjectsAffectedBySeriousAdverseEvents = serious, 
                            subjectsAffectedByNonSeriousAdverseEvents = 1 - serious) ~ subjid + group, 
                      data = safety, FUN = max, na.rm = TRUE)


# to count them all up by group

df_group <- aggregate(cbind(deathsResultingFromAdverseEvents, subjectsAffectedBySeriousAdverseEvents, 
                            subjectsAffectedByNonSeriousAdverseEvents) ~ group, FUN = sum, data = df_group)

# Checks on the the number exposed
patient_numbers <- xtabs(~group, data = unique(subset(safety, select = c(subjid, 
                                                                             group))))

if (any(patient_numbers > subjectsExposed)) {
  warning("You have more patients in the safety data, than SubjectExposed")
}

df_group <- cbind(df_group, subjectsExposed, deathsAllCauses = df_group$deathsResultingFromAdverseEvents + 
                    deathsExternal)
names(df_group)[1] <- "title"

# tabulation at the individual term level

# create a unique label
safety$patient <- with(safety, 1 - duplicated(cbind(subjid, serious, pt, term, 
                                                    eutctId)))
safety$term_long <- with(safety, paste(pt, term, eutctId, sep = "_"))
# to merge back in later
safety_events <- subset(safety, select = c(pt, term, eutctId, term_long))
safety_events <- unique(safety_events)

# serious table has to count up death information

serious_freq_table <- aggregate(cbind(subjectsAffected = patient, 
                                      occurrences = 1, 
                                      occurrencesCausallyRelatedToTreatment = related, deaths = fatal, deathsCausallyRelatedToTreatment = fatal * 
                                        related) ~ term_long + group, data = safety, subset = (serious == 1), 
                                FUN = sum, drop = FALSE, simplify = TRUE)
# Need to have rows for each group even if zero so drop = FALSE

serious_freq_table <- merge(serious_freq_table, safety_events, by = "term_long", 
                            all.x = TRUE)
serious_freq_table <- merge(serious_freq_table, df_group, by.x = "group", by.y = "title", 
                            all.x = TRUE)


# CHECK
# There are no non-serious events recorded


aes <- read_xml(system.file("extdata", "aes.xml", package = "EudractSafetyXml"))

# re-set the reporting frequency for non-serious events

threshold_node <- xml_find_first(aes, "//nonSeriousEventFrequencyThreshold")
xml_text(threshold_node) <- as.character(nonSeriousEventFrequencyThreshold)

# get the reportGroups node,
reportingGroups <- xml_find_first(aes, "//reportingGroups")


# loop through the rows of df
for (i in 1:nrow(df_group)) {
  # create a new blank node group
  group <- read_xml(system.file("extdata", "blank_group.xml", package = "EudractSafetyXml"))
  xml_attrs(group) <- c(id = paste0("ReportingGroup-", i))
  # add the elements from row i
  add_xml_elements(group, df_group[i, ])
  # add the modified group node to the reportingGroups
  xml_add_child(reportingGroups, group)
}


seriouses <- xml_find_first(aes, "//seriousAdverseEvents")
add_ae_table(serious_freq_table, seriouses, type = "serious")

#nonSeriouses <- xml_find_first(aes, "//nonSeriousAdverseEvents")
#add_ae_table(non_serious_freq_table, nonSeriouses, type = "nonSerious")


write_xml(aes, "safety_upload.xml")

myschema <- read_xml(system.file("extdata","adverseEvents.xsd", package="EudractSafetyXml"))
check <- xml_validate(aes,myschema)
if(check){print("Validation against the schema has passed!")}
