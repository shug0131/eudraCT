
#get a list of all the files in the directoy
funcs=dir(paste(PATH,"/Progs/Functions",sep=""))
#remove the NotUsed subdirectory
funcs <- funcs[ funcs!="NotUsed" ]

#source them
for( func in funcs){
source(paste(PATH,"/Progs/Functions/",func, sep=""),echo=F)
}


rm(func, funcs)

# load up the libraries

project_packages <- c("XML","ggplot2","scales","survival",
                      "gridExtra","plyr", "data.table",
                      "lme4","nlme","xtable","VIM", "mitools"
                      )
for(package in project_packages){ library(package, character.only = TRUE)}
rm(project_packages)

